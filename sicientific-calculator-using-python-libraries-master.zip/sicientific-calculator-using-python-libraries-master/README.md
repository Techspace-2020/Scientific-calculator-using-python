# sicientific-calculator-using-python-libraries
Project includes both features i.e.., standard and scientific calculator. The source code is written using python and its libraries
